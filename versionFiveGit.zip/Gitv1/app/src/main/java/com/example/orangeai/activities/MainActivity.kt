package com.example.orangeai.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

import com.example.orangeai.R
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.projemanag.firebase.FirestoreClass


import kotlinx.android.synthetic.main.activity_main.*
class MainActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        home_move.setOnClickListener {
            intent = Intent(this@MainActivity, ExerciseActivity::class.java)
            startActivity(intent)
            finish()
        }
        home_diet.setOnClickListener {
            intent = Intent(this@MainActivity, DietActivity::class.java)
            startActivity(intent)
            finish()
        }
        home_profile.setOnClickListener {
            intent = Intent(this@MainActivity, ProfileActivity::class.java)
            startActivity(intent)
            finish()
        }





    }

}

