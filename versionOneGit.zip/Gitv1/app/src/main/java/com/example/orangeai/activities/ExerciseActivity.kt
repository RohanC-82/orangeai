package com.example.orangeai.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.example.orangeai.R
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.activity_exercise.*
import kotlinx.android.synthetic.main.activity_main.*

class ExerciseActivity : BaseActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exercise)
        exercise_home.setOnClickListener {
            intent = Intent(this@ExerciseActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
        exercise_diet.setOnClickListener {
            intent = Intent(this@ExerciseActivity, DietActivity::class.java)
            startActivity(intent)
            finish()
        }
        exercise_profile.setOnClickListener {
            intent = Intent(this@ExerciseActivity, ProfileActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}