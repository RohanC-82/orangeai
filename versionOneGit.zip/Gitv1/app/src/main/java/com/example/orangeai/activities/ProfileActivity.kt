package com.example.orangeai.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import com.example.orangeai.R
import com.example.orangeai.models.User
import com.example.orangeai.utils.Constants
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuth.AuthStateListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_profile.*
import java.util.*

class ProfileActivity : BaseActivity() {





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        profile_home.setOnClickListener {
            intent = Intent(this@ProfileActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
        profile_move.setOnClickListener {
            intent = Intent(this@ProfileActivity, ExerciseActivity::class.java)
            startActivity(intent)
            finish()
        }
        profile_diet.setOnClickListener {
            intent = Intent(this@ProfileActivity, DietActivity::class.java)
            startActivity(intent)
            finish()
        }
        log_out_profile.setOnClickListener {
            signOutFirebase()
        }
        val TAG = javaClass.simpleName
        pFireStore.collection(Constants.USERS)
            .document(getCurrentUserID())
            .get()
            .addOnSuccessListener { document ->
                Log.e(TAG, document.toString())

                // Here we have received the document snapshot which is converted into the User Data model object.
                val userProfile = document.toObject(User::class.java)!!
                getUserDetails(userProfile)
            }
            .addOnFailureListener { e ->
                // END
                Log.e(
                    TAG, "Error while getting loggedIn user details", e)
            }


    }

    fun getUserDetails(userp: User) {
        tv_profile_name.text = userp.name

    }










    private fun signOutFirebase(){
        FirebaseAuth.getInstance().signOut()
        finish()
        intent = Intent(this@ProfileActivity, IntroActivity::class.java)
        startActivity(intent)
    }

    fun retrieveFirebaseData() {

    }
}