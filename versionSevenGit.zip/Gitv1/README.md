# OrangeAI

Log your diet and lifestyle activities through taking pictures of food. There can be different modes: Exersice, Nutrition, Diet.
