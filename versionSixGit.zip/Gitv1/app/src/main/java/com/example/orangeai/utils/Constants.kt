package com.example.orangeai.utils

object Constants {

    const val USERS: String = "Users"
}